/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package packUtilidades;

/**
 *
 * @author pedro
 */
import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Bd {
    
    Connection conn=null;
    
    public Connection createConnection(){
        
        try {
            Class.forName("com.mysql.jdbc.Driver");
            this.conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/ejercicio_tienda","root","root");
        
        
        } catch (SQLException ex) {
            Logger.getLogger(Bd.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(Bd.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        
        return this.conn;
    }
    
}
