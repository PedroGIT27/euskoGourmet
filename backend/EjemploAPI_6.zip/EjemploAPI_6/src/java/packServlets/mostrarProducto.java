/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package packServlets;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import java.io.IOException;
import java.io.PrintWriter;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import packUtilidades.Bd;
import java.sql.*;

/**
 *
 * @author pedro
 */
@WebServlet(name = "mostrarProducto", urlPatterns = {"/mostrarProducto"})
public class mostrarProducto extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        
       
        
    JsonArray ja=new JsonArray();
    
    Connection conn=null;
    
    Bd db=new Bd();
 
        try {
               
    conn=db.createConnection();
            PreparedStatement ps=conn.prepareStatement("Select * from tienda");
        
              ResultSet rs=ps.executeQuery();
              while(rs.next()){
                  
                  JsonObject jo=new JsonObject();
                  jo.addProperty("idtienda", rs.getInt("idtienda"));
                     jo.addProperty("titulo", rs.getString("titulo"));
                        jo.addProperty("precio", rs.getDouble("precio"));
                           jo.addProperty("url", rs.getString("url"));
                              jo.addProperty("vendido", rs.getBoolean("vendido"));
                              ja.add(jo);
                  
              }
              
              ps.executeUpdate();
              conn.close();
              ps.close();
        } catch (SQLException ex) {
            Logger.getLogger(aniadirProducto.class.getName()).log(Level.SEVERE, null, ex);
        }
    
        
        PrintWriter out=response.getWriter();
        out.print(ja);
        out.flush();
        
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
